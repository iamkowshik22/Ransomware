import subprocess
subprocess.run(["attrib","-H","D:/det.txt"],check=True)
